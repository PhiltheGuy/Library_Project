package databaseproject2024;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class LibraryBrowsePage extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable bookTable, movieTable, gameTable;
    private DefaultTableModel bookTableModel, movieTableModel, gameTableModel;
    private JTextField titleField, authorField, genreField, minPageField, maxPageField, branchField;
    private JCheckBox authorCheck, genreCheck, pageRangeCheck, branchCheck;
    private JTextField movieTitleField, gameTitleField, runtimeMinField, runtimeMaxField, movieGenreField, gameGenreField;
    private JCheckBox movieGenreCheck, runtimeCheck, gameGenreCheck;

    private final String server = "LAPTOP-EBU3JLQG";
    private final String databaseName = "MyLibraryDatabase";
    private final String connectionUrl = "jdbc:sqlserver://" + server + ":1433;databaseName=" + databaseName + ";integratedSecurity=true;encrypt=false;";

    private String currentUserId;

    public LibraryBrowsePage(String userId) {
        this.currentUserId = userId;

        // Set up frame
        setTitle("Library Browser");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Tabbed pane
        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Books", createBookTab());
        tabbedPane.addTab("Movies", createMovieTab());
        tabbedPane.addTab("Games", createGameTab());

        // Bottom panel
        JPanel bottomPanel = new JPanel();
        JButton returnAllButton = new JButton("Return All Items");
        JButton checkOutSelectedButton = new JButton("Check Out Selected Items");

        returnAllButton.addActionListener(e -> returnAllItems());
        checkOutSelectedButton.addActionListener(e -> checkOutSelectedItems());

        bottomPanel.add(returnAllButton);
        bottomPanel.add(checkOutSelectedButton);
        add(bottomPanel, BorderLayout.SOUTH);

        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel createBookTab() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new BorderLayout());

        // Search bar
        titleField = new JTextField();
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(e -> searchBooks());
        topPanel.add(new JLabel("Search by Title: "), BorderLayout.WEST);
        topPanel.add(titleField, BorderLayout.CENTER);
        topPanel.add(searchButton, BorderLayout.EAST);

        // Filters
        JPanel filterPanel = new JPanel(new GridLayout(0, 2));
        authorCheck = new JCheckBox("Filter by Author");
        authorField = new JTextField();
        genreCheck = new JCheckBox("Filter by Genre");
        genreField = new JTextField();
        pageRangeCheck = new JCheckBox("Filter by Page Number");
        minPageField = new JTextField("Min Pages");
        maxPageField = new JTextField("Max Pages");
        branchCheck = new JCheckBox("Filter by Branch");
        branchField = new JTextField();

        filterPanel.add(authorCheck);
        filterPanel.add(authorField);
        filterPanel.add(genreCheck);
        filterPanel.add(genreField);
        filterPanel.add(pageRangeCheck);
        JPanel pagePanel = new JPanel(new GridLayout(1, 2));
        pagePanel.add(minPageField);
        pagePanel.add(maxPageField);
        filterPanel.add(pagePanel);
        filterPanel.add(branchCheck);
        filterPanel.add(branchField);

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(filterPanel, BorderLayout.EAST);

        // Table
        bookTableModel = new DefaultTableModel(new String[]{"Title", "Author", "Genre", "Page Number", "Branch"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        bookTable = new JTable(bookTableModel);
        bookTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        panel.add(new JScrollPane(bookTable), BorderLayout.CENTER);

        return panel;
    }

    private JPanel createMovieTab() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new BorderLayout());

        // Search bar
        movieTitleField = new JTextField();
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(e -> searchMovies());
        topPanel.add(new JLabel("Search by Title: "), BorderLayout.WEST);
        topPanel.add(movieTitleField, BorderLayout.CENTER);
        topPanel.add(searchButton, BorderLayout.EAST);

        // Filters
        JPanel filterPanel = new JPanel(new GridLayout(0, 2));
        movieGenreCheck = new JCheckBox("Filter by Genre");
        movieGenreField = new JTextField();
        runtimeCheck = new JCheckBox("Filter by Runtime");
        runtimeMinField = new JTextField("Min Runtime");
        runtimeMaxField = new JTextField("Max Runtime");

        filterPanel.add(movieGenreCheck);
        filterPanel.add(movieGenreField);
        filterPanel.add(runtimeCheck);
        JPanel runtimePanel = new JPanel(new GridLayout(1, 2));
        runtimePanel.add(runtimeMinField);
        runtimePanel.add(runtimeMaxField);
        filterPanel.add(runtimePanel);

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(filterPanel, BorderLayout.EAST);

        // Table
        movieTableModel = new DefaultTableModel(new String[]{"Title", "Genre", "Runtime"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        movieTable = new JTable(movieTableModel);
        movieTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        panel.add(new JScrollPane(movieTable), BorderLayout.CENTER);

        return panel;
    }

    private JPanel createGameTab() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new BorderLayout());

        // Search bar
        gameTitleField = new JTextField();
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(e -> searchGames());
        topPanel.add(new JLabel("Search by Title: "), BorderLayout.WEST);
        topPanel.add(gameTitleField, BorderLayout.CENTER);
        topPanel.add(searchButton, BorderLayout.EAST);

        // Filters
        JPanel filterPanel = new JPanel(new GridLayout(0, 2));
        gameGenreCheck = new JCheckBox("Filter by Genre");
        gameGenreField = new JTextField();

        filterPanel.add(gameGenreCheck);
        filterPanel.add(gameGenreField);

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(filterPanel, BorderLayout.EAST);

        // Table
        gameTableModel = new DefaultTableModel(new String[]{"Title", "Genre"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };
        gameTable = new JTable(gameTableModel);
        gameTable.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        panel.add(new JScrollPane(gameTable), BorderLayout.CENTER);

        return panel;
    }

    private void searchBooks() {
        String title = titleField.getText().trim();
        ArrayList<Object> parameters = new ArrayList<>();
        StringBuilder query = new StringBuilder("SELECT * FROM Books WHERE title LIKE ? AND check_out_by IS NULL");
        parameters.add("%" + title + "%");

        if (authorCheck.isSelected() && !authorField.getText().isEmpty()) {
            query.append(" AND author = ?");
            parameters.add(authorField.getText().trim());
        }
        if (genreCheck.isSelected() && !genreField.getText().isEmpty()) {
            query.append(" AND genre = ?");
            parameters.add(genreField.getText().trim());
        }
        if (pageRangeCheck.isSelected() && !minPageField.getText().isEmpty() && !maxPageField.getText().isEmpty()) {
            query.append(" AND page_number BETWEEN ? AND ?");
            parameters.add(Integer.parseInt(minPageField.getText().trim()));
            parameters.add(Integer.parseInt(maxPageField.getText().trim()));
        }
        if (branchCheck.isSelected() && !branchField.getText().isEmpty()) {
            query.append(" AND branch = ?");
            parameters.add(branchField.getText().trim());
        }

        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query.toString())) {
            for (int i = 0; i < parameters.size(); i++) {
                stmt.setObject(i + 1, parameters.get(i));
            }
            ResultSet rs = stmt.executeQuery();

            bookTableModel.setRowCount(0); // Clear the table
            while (rs.next()) {
                bookTableModel.addRow(new Object[]{
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("genre"),
                        rs.getInt("page_number"),
                        rs.getString("branch")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error searching books: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void searchMovies() {
        String title = movieTitleField.getText().trim();
        ArrayList<Object> parameters = new ArrayList<>();
        StringBuilder query = new StringBuilder("SELECT * FROM Movie WHERE title LIKE ? AND check_out_by IS NULL");
        parameters.add("%" + title + "%");

        if (movieGenreCheck.isSelected() && !movieGenreField.getText().isEmpty()) {
            query.append(" AND genre = ?");
            parameters.add(movieGenreField.getText().trim());
        }
        if (runtimeCheck.isSelected() && !runtimeMinField.getText().isEmpty() && !runtimeMaxField.getText().isEmpty()) {
            query.append(" AND runtime BETWEEN ? AND ?");
            parameters.add(Integer.parseInt(runtimeMinField.getText().trim()));
            parameters.add(Integer.parseInt(runtimeMaxField.getText().trim()));
        }

        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query.toString())) {
            for (int i = 0; i < parameters.size(); i++) {
                stmt.setObject(i + 1, parameters.get(i));
            }
            ResultSet rs = stmt.executeQuery();

            movieTableModel.setRowCount(0); // Clear the table
            while (rs.next()) {
                movieTableModel.addRow(new Object[]{
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getInt("runtime")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error searching movies: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void searchGames() {
        String title = gameTitleField.getText().trim();
        ArrayList<Object> parameters = new ArrayList<>();
        StringBuilder query = new StringBuilder("SELECT * FROM Games WHERE title LIKE ? AND check_out_by IS NULL");
        parameters.add("%" + title + "%");

        if (gameGenreCheck.isSelected() && !gameGenreField.getText().isEmpty()) {
            query.append(" AND genre = ?");
            parameters.add(gameGenreField.getText().trim());
        }

        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query.toString())) {
            for (int i = 0; i < parameters.size(); i++) {
                stmt.setObject(i + 1, parameters.get(i));
            }
            ResultSet rs = stmt.executeQuery();

            gameTableModel.setRowCount(0); // Clear the table
            while (rs.next()) {
                gameTableModel.addRow(new Object[]{
                        rs.getString("title"),
                        rs.getString("genre")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error searching games: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    
   private void checkOutSelectedItems() {
    // Check for selected books
    int[] selectedRows = bookTable.getSelectedRows();
    if (selectedRows.length == 0 && movieTable.getSelectedRows().length == 0 && gameTable.getSelectedRows().length == 0) {
        JOptionPane.showMessageDialog(this, "Please select at least one item to check out.",
                "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Check out books
    for (int rowIndex : selectedRows) {
        String title = (String) bookTable.getValueAt(rowIndex, 0); // Title column for books
        checkoutItem("Books", title);
    }

    // Check out movies
    selectedRows = movieTable.getSelectedRows();
    for (int rowIndex : selectedRows) {
        String title = (String) movieTable.getValueAt(rowIndex, 0); // Title column for movies
        checkoutItem("Movie", title);
    }

    // Check out games
    selectedRows = gameTable.getSelectedRows();
    for (int rowIndex : selectedRows) {
        String title = (String) gameTable.getValueAt(rowIndex, 0); // Title column for games
        checkoutItem("Games", title);
    }
}


private void checkoutItem(String type, String title) {
    String query = "UPDATE " + type + " SET check_out_by = ? WHERE title = ? AND check_out_by IS NULL";

    try (Connection conn = DriverManager.getConnection(connectionUrl);
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setString(1, currentUserId);
        stmt.setString(2, title);

        int rowsUpdated = stmt.executeUpdate();
        if (rowsUpdated == 0) {
            JOptionPane.showMessageDialog(this, "The item '" + title + "' is already checked out or not found.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Successfully checked out '" + title + "'.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            refreshTables();
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error checking out item: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void returnAllItems() {
    String queryBook = "UPDATE Books SET check_out_by = NULL WHERE check_out_by = ?";
    String queryMovie = "UPDATE Movie SET check_out_by = NULL WHERE check_out_by = ?";
    String queryGame = "UPDATE Games SET check_out_by = NULL WHERE check_out_by = ?";

    try (Connection conn = DriverManager.getConnection(connectionUrl)) {
        try (PreparedStatement stmtBook = conn.prepareStatement(queryBook);
             PreparedStatement stmtMovie = conn.prepareStatement(queryMovie);
             PreparedStatement stmtGame = conn.prepareStatement(queryGame)) {

            // Set the current user ID for each update
            stmtBook.setString(1, currentUserId);
            stmtMovie.setString(1, currentUserId);
            stmtGame.setString(1, currentUserId);

            // Execute the updates
            int rowsUpdatedBooks = stmtBook.executeUpdate();
            int rowsUpdatedMovies = stmtMovie.executeUpdate();
            int rowsUpdatedGames = stmtGame.executeUpdate();

            if (rowsUpdatedBooks == 0 && rowsUpdatedMovies == 0 && rowsUpdatedGames == 0) {
                JOptionPane.showMessageDialog(this, "No items were found to return for your user.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Successfully returned all checked-out items.",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            }

            // Refresh tables after return
            refreshTables();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error returning items: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Database connection error: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}


private void returnItem(String type, String title) {
    String query = "UPDATE " + type + " SET check_out_by = NULL WHERE title = ? AND check_out_by = ?";

    try (Connection conn = DriverManager.getConnection(connectionUrl);
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setString(1, title);
        stmt.setString(2, currentUserId);

        int rowsUpdated = stmt.executeUpdate();
        if (rowsUpdated == 0) {
            JOptionPane.showMessageDialog(this, "The item '" + title + "' is not checked out by you.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Successfully returned '" + title + "'.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            refreshTables();
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error returning item: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void refreshTables() {
    searchBooks(); // Re-fetch the books to update the table view
    searchMovies(); // Re-fetch the movies to update the table view
    searchGames(); // Re-fetch the games to update the table view
}

    
    
    
    
    
    
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LibraryBrowsePage frame = new LibraryBrowsePage("user1");
            frame.setVisible(true);
        });
    }
}
