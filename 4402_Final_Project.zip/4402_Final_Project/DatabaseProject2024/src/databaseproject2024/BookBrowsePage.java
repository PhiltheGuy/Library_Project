package databaseproject2024;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class BookBrowsePage extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable bookTable;
    private DefaultTableModel bookTableModel;
    private JTextField searchField;
    private JCheckBox authorCheck, genreCheck, pageRangeCheck, branchCheck;

    private final String server = "LAPTOP-EBU3JLQG";
    private final String databaseName = "MyLibraryDatabase";
    private final String connectionUrl = "jdbc:sqlserver://" + server + ":1433;databaseName=" + databaseName + ";integratedSecurity=true;encrypt=false;";

    private String currentUserId;

    public BookBrowsePage(String userId) {
        this.currentUserId = userId;

        // Set up frame
        setTitle("Library Browser");
        setSize(900, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Tabbed pane
        tabbedPane = new JTabbedPane();

        tabbedPane.addTab("Books", createBookTab());
        // Placeholder for Movies and Games tabs
        tabbedPane.addTab("Movies", new JPanel()); 
        tabbedPane.addTab("Games", new JPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel createBookTab() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new BorderLayout());

        // Search bar
        searchField = new JTextField();
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(e -> searchBooks());
        topPanel.add(new JLabel("Search by Title: "), BorderLayout.WEST);
        topPanel.add(searchField, BorderLayout.CENTER);
        topPanel.add(searchButton, BorderLayout.EAST);

        // Filters
        JPanel filterPanel = new JPanel(new GridLayout(0, 1));
        authorCheck = new JCheckBox("Filter by Author");
        genreCheck = new JCheckBox("Filter by Genre");
        pageRangeCheck = new JCheckBox("Filter by Page Range");
        branchCheck = new JCheckBox("Filter by Branch");

        filterPanel.add(authorCheck);
        filterPanel.add(genreCheck);
        filterPanel.add(pageRangeCheck);
        filterPanel.add(branchCheck);

        // Add filter panel
        JPanel sidePanel = new JPanel(new BorderLayout());
        sidePanel.add(new JLabel("Filters:"), BorderLayout.NORTH);
        sidePanel.add(filterPanel, BorderLayout.CENTER);
        panel.add(sidePanel, BorderLayout.EAST);

        // Table
        bookTableModel = new DefaultTableModel(new String[]{"Title", "Author", "Genre"}, 0); // Hides Book ID
        bookTable = new JTable(bookTableModel);
        JScrollPane scrollPane = new JScrollPane(bookTable);

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void searchBooks() {
        String baseQuery = "SELECT title, author, genre FROM Books";
        StringBuilder queryBuilder = new StringBuilder(baseQuery);
        boolean hasFilter = false;

        // Add filters dynamically based on checkbox selections
        if (authorCheck.isSelected()) {
            queryBuilder.append(hasFilter ? " AND" : " WHERE").append(" author LIKE ?");
            hasFilter = true;
        }
        if (genreCheck.isSelected()) {
            queryBuilder.append(hasFilter ? " AND" : " WHERE").append(" genre LIKE ?");
            hasFilter = true;
        }
        if (pageRangeCheck.isSelected()) {
            queryBuilder.append(hasFilter ? " AND" : " WHERE").append(" page_count BETWEEN ? AND ?");
            hasFilter = true;
        }
        if (branchCheck.isSelected()) {
            queryBuilder.append(hasFilter ? " AND" : " WHERE").append(" branch = ?");
            hasFilter = true;
        }

        String query = queryBuilder.toString();

        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            int paramIndex = 1;

            // Set parameters based on filter inputs
            if (authorCheck.isSelected()) stmt.setString(paramIndex++, "%" + searchField.getText() + "%");
            if (genreCheck.isSelected()) stmt.setString(paramIndex++, "%" + searchField.getText() + "%");
            if (pageRangeCheck.isSelected()) {
                // Example range for demo purposes; replace with actual user input
                stmt.setInt(paramIndex++, 100); // Minimum pages
                stmt.setInt(paramIndex++, 500); // Maximum pages
            }
            if (branchCheck.isSelected()) stmt.setString(paramIndex++, searchField.getText());

            // Execute query and populate table
            try (ResultSet rs = stmt.executeQuery()) {
                bookTableModel.setRowCount(0); // Clear table
                while (rs.next()) {
                    String title = rs.getString("title");
                    String author = rs.getString("author");
                    String genre = rs.getString("genre");
                    bookTableModel.addRow(new Object[]{title, author, genre});
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading books: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BookBrowsePage("user123").setVisible(true));
    }
}
