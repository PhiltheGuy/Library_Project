
package databaseproject2024;

//Class meant to allow users to query for books using buttons


public class book_query {
    
    
    
    
    
}
