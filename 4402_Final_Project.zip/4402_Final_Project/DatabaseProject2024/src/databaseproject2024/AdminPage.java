package databaseproject2024;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AdminPage extends JFrame {
    private final String server = "LAPTOP-EBU3JLQG";
    private final String databaseName = "MyLibraryDatabase";
    private final String connectionUrl = "jdbc:sqlserver://" + server + ":1433;databaseName=" + databaseName + ";integratedSecurity=true;encrypt=false;";
    private String currentUserId;

    public AdminPage(String userId) {
        this.currentUserId = userId;

        // Set up frame
        setTitle("Rosewood Library - Admin Page");
        setSize(800, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JLabel headerLabel = new JLabel("Admin Functions", SwingConstants.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(headerLabel, BorderLayout.NORTH);

        // Create tabs
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Add Books", createAddBooksPanel());
        tabbedPane.addTab("Add Movies", createAddMoviesPanel());
        tabbedPane.addTab("Add Games", createAddGamesPanel());
        tabbedPane.addTab("Delete Books", createDeleteBooksPanel());
        tabbedPane.addTab("Delete Movies", createDeleteMoviesPanel());
        tabbedPane.addTab("Delete Games", createDeleteGamesPanel());
        add(tabbedPane, BorderLayout.CENTER);
    }

    // Panel to add books
    private JPanel createAddBooksPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(8, 2, 10, 10));

        // Input fields
        JLabel bookIdLabel = new JLabel("Book ID:");
        JTextField bookIdField = new JTextField();

        JLabel titleLabel = new JLabel("Title:");
        JTextField titleField = new JTextField();

        JLabel authorLabel = new JLabel("Author:");
        JTextField authorField = new JTextField();

        JLabel genreLabel = new JLabel("Genre:");
        JTextField genreField = new JTextField();

        JLabel pageLabel = new JLabel("Page Number:");
        JTextField pageField = new JTextField();

        JLabel branchLabel = new JLabel("Branch:");
        JTextField branchField = new JTextField();

        JButton addButton = new JButton("Add Book");
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setForeground(Color.RED);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int bookId = Integer.parseInt(bookIdField.getText());
                    String title = titleField.getText();
                    String author = authorField.getText();
                    String genre = genreField.getText();
                    int pages = Integer.parseInt(pageField.getText());
                    String branch = branchField.getText();

                    if (addBookToDatabase(bookId, title, author, genre, pages, branch)) {
                        messageLabel.setText("Book added successfully!");
                        messageLabel.setForeground(Color.GREEN);
                    } else {
                        messageLabel.setText("Failed to add book.");
                        messageLabel.setForeground(Color.RED);
                    }
                } catch (NumberFormatException ex) {
                    messageLabel.setText("Invalid input. Please ensure all fields are correctly filled.");
                    messageLabel.setForeground(Color.RED);
                }
            }
        });

        // Add components to panel
        panel.add(bookIdLabel);
        panel.add(bookIdField);
        panel.add(titleLabel);
        panel.add(titleField);
        panel.add(authorLabel);
        panel.add(authorField);
        panel.add(genreLabel);
        panel.add(genreField);
        panel.add(pageLabel);
        panel.add(pageField);
        panel.add(branchLabel);
        panel.add(branchField);
        panel.add(addButton);
        panel.add(messageLabel);

        return panel;
    }

    // Panel to add movies
    private JPanel createAddMoviesPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2, 10, 10));

        // Input fields
        JLabel movieIdLabel = new JLabel("Movie ID:");
        JTextField movieIdField = new JTextField();

        JLabel movieTitleLabel = new JLabel("Title:");
        JTextField movieTitleField = new JTextField();

        JLabel genreLabel = new JLabel("Genre:");
        JTextField movieGenreField = new JTextField();

        JLabel durationLabel = new JLabel("Duration (in minutes):");
        JTextField durationField = new JTextField();

        JButton addButton = new JButton("Add Movie");
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setForeground(Color.RED);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int movieId = Integer.parseInt(movieIdField.getText());
                    String title = movieTitleField.getText();
                    String genre = movieGenreField.getText();
                    int duration = Integer.parseInt(durationField.getText());

                    if (addMovieToDatabase(movieId, title, genre, duration)) {
                        messageLabel.setText("Movie added successfully!");
                        messageLabel.setForeground(Color.GREEN);
                    } else {
                        messageLabel.setText("Failed to add movie.");
                        messageLabel.setForeground(Color.RED);
                    }
                } catch (NumberFormatException ex) {
                    messageLabel.setText("Invalid input. Please ensure all fields are correctly filled.");
                    messageLabel.setForeground(Color.RED);
                }
            }
        });

        // Add components to panel
        panel.add(movieIdLabel);
        panel.add(movieIdField);
        panel.add(movieTitleLabel);
        panel.add(movieTitleField);
        panel.add(genreLabel);
        panel.add(movieGenreField);
        panel.add(durationLabel);
        panel.add(durationField);
        panel.add(addButton);
        panel.add(messageLabel);

        return panel;
    }

    // Panel to add games
    private JPanel createAddGamesPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2, 10, 10));

        // Input fields
        JLabel gameIdLabel = new JLabel("Game ID:");
        JTextField gameIdField = new JTextField();

        JLabel gameTitleLabel = new JLabel("Title:");
        JTextField gameTitleField = new JTextField();

        JLabel genreLabel = new JLabel("Genre:");
        JTextField gameGenreField = new JTextField();

        JButton addButton = new JButton("Add Game");
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setForeground(Color.RED);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int gameId = Integer.parseInt(gameIdField.getText());
                    String title = gameTitleField.getText();
                    String genre = gameGenreField.getText();

                    if (addGameToDatabase(gameId, title, genre)) {
                        messageLabel.setText("Game added successfully!");
                        messageLabel.setForeground(Color.GREEN);
                    } else {
                        messageLabel.setText("Failed to add game.");
                        messageLabel.setForeground(Color.RED);
                    }
                } catch (NumberFormatException ex) {
                    messageLabel.setText("Invalid input. Please ensure all fields are correctly filled.");
                    messageLabel.setForeground(Color.RED);
                }
            }
        });

        // Add components to panel
        panel.add(gameIdLabel);
        panel.add(gameIdField);
        panel.add(gameTitleLabel);
        panel.add(gameTitleField);
        panel.add(genreLabel);
        panel.add(gameGenreField);
        panel.add(addButton);
        panel.add(messageLabel);

        return panel;
    }

    // Panel to delete books
    private JPanel createDeleteBooksPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));

        JLabel bookIdLabel = new JLabel("Book ID:");
        JTextField bookIdField = new JTextField();

        JButton deleteButton = new JButton("Delete Book");
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setForeground(Color.RED);

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int bookId = Integer.parseInt(bookIdField.getText());

                    if (deleteBookFromDatabase(bookId)) {
                        messageLabel.setText("Book deleted successfully!");
                        messageLabel.setForeground(Color.GREEN);
                    } else {
                        messageLabel.setText("Failed to delete book.");
                        messageLabel.setForeground(Color.RED);
                    }
                } catch (NumberFormatException ex) {
                    messageLabel.setText("Invalid Book ID. Please enter a valid number.");
                    messageLabel.setForeground(Color.RED);
                }
            }
        });

        // Add components to panel
        panel.add(bookIdLabel);
        panel.add(bookIdField);
        panel.add(deleteButton);
        panel.add(messageLabel);

        return panel;
    }

    // Panel to delete movies
    private JPanel createDeleteMoviesPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));

        JLabel movieIdLabel = new JLabel("Movie ID:");
        JTextField movieIdField = new JTextField();

        JButton deleteButton = new JButton("Delete Movie");
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setForeground(Color.RED);

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int movieId = Integer.parseInt(movieIdField.getText());

                    if (deleteMovieFromDatabase(movieId)) {
                        messageLabel.setText("Movie deleted successfully!");
                        messageLabel.setForeground(Color.GREEN);
                    } else {
                        messageLabel.setText("Failed to delete movie.");
                        messageLabel.setForeground(Color.RED);
                    }
                } catch (NumberFormatException ex) {
                    messageLabel.setText("Invalid Movie ID. Please enter a valid number.");
                    messageLabel.setForeground(Color.RED);
                }
            }
        });

        // Add components to panel
        panel.add(movieIdLabel);
        panel.add(movieIdField);
        panel.add(deleteButton);
        panel.add(messageLabel);

        return panel;
    }

    // Panel to delete games
    private JPanel createDeleteGamesPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 10, 10));

        JLabel gameIdLabel = new JLabel("Game ID:");
        JTextField gameIdField = new JTextField();

        JButton deleteButton = new JButton("Delete Game");
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);
        messageLabel.setForeground(Color.RED);

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int gameId = Integer.parseInt(gameIdField.getText());

                    if (deleteGameFromDatabase(gameId)) {
                        messageLabel.setText("Game deleted successfully!");
                        messageLabel.setForeground(Color.GREEN);
                    } else {
                        messageLabel.setText("Failed to delete game.");
                        messageLabel.setForeground(Color.RED);
                    }
                } catch (NumberFormatException ex) {
                    messageLabel.setText("Invalid Game ID. Please enter a valid number.");
                    messageLabel.setForeground(Color.RED);
                }
            }
        });

        // Add components to panel
        panel.add(gameIdLabel);
        panel.add(gameIdField);
        panel.add(deleteButton);
        panel.add(messageLabel);

        return panel;
    }

    // Method to delete a book from the database
    private boolean deleteBookFromDatabase(int bookId) {
        String query = "DELETE FROM Books WHERE book_id = ?";
        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bookId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete a movie from the database
    private boolean deleteMovieFromDatabase(int movieId) {
        String query = "DELETE FROM movie WHERE movie_id = ?";
        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, movieId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete a game from the database
    private boolean deleteGameFromDatabase(int gameId) {
        String query = "DELETE FROM Games WHERE game_id = ?";
        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, gameId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to add a book to the database
    private boolean addBookToDatabase(int bookId, String title, String author, String genre, int pages, String branch) {
        String query = "INSERT INTO Books (book_id, title, author, genre, page_number, branch) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, bookId);
            stmt.setString(2, title);
            stmt.setString(3, author);
            stmt.setString(4, genre);
            stmt.setInt(5, pages);
            stmt.setString(6, branch);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to add a movie to the database
    private boolean addMovieToDatabase(int movieId, String title, String genre, int duration) {
        String query = "INSERT INTO movie (movie_id, title, genre, duration) VALUES (?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, movieId);
            stmt.setString(2, title);
            stmt.setString(3, genre);
            stmt.setInt(4, duration);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to add a game to the database
    private boolean addGameToDatabase(int gameId, String title, String genre) {
        String query = "INSERT INTO Games (game_id, title, genre) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, gameId);
            stmt.setString(2, title);
            stmt.setString(3, genre);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
