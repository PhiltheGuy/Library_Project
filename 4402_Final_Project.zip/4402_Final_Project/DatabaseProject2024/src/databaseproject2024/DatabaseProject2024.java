package databaseproject2024;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;

public class DatabaseProject2024 
{

    public static void main(String[] args) 
    {
        // Specify the SQL Server instance and database name
        String server = "LAPTOP-EBU3JLQG";  
        String databaseName = "MyLibraryDatabase";  
        String url = "jdbc:sqlserver://" + server + ":1433;databaseName=" + databaseName + ";integratedSecurity=true;encrypt=false;";
        LoginForm theLoginForm = new LoginForm();
        theLoginForm.setVisible(true);
        
        
    }

    // Test method: Query for books by title
    public static void book_search(String title) 
    {
        String server = "LAPTOP-EBU3JLQG";  
        String databaseName = "MyLibraryDatabase";  
        String url = "jdbc:sqlserver://" + server + ":1433;databaseName=" + databaseName + ";integratedSecurity=true;encrypt=false;";

        // Start the query with IS NULL for check_out_by
        String queryGet = "SELECT title FROM Books WHERE check_out_by IS NULL AND title = '" + title + "'";

        try 
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            try (Connection conn = DriverManager.getConnection(url)) 
            {
                Statement bookGet = conn.createStatement();
                ResultSet theResult = bookGet.executeQuery(queryGet);

                while (theResult.next()) 
                {
                    String titler = theResult.getString("title");
                    System.out.println("Found book: " + titler);
                }
            }
        } 
        catch (ClassNotFoundException e) 
        {
            System.out.println("SQL Server JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Test method: Query for books with conditions (page, author, genre)
    public static void book_query(int minPage, int maxPage, String author, String genre) { 
        String server = "LAPTOP-EBU3JLQG";  
        String databaseName = "MyLibraryDatabase";  
        String url = "jdbc:sqlserver://" + server + ":1433;databaseName=" + databaseName + ";integratedSecurity=true;encrypt=false;";

        String queryGet = "SELECT title FROM Books WHERE check_out_by IS NULL ";

        try 
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            try (Connection conn = DriverManager.getConnection(url)) 
            {
                Statement bookGet = conn.createStatement();

                // Add conditions to the query based on input parameters
                if (minPage > 0) {
                    queryGet += " AND page_number >= " + minPage;
                }
                if (maxPage != 0) {
                    queryGet += " AND page_number <= " + maxPage;
                }
                if (author != null && !author.isEmpty()) {
                    queryGet += " AND author = '" + author + "'"; 
                }
                if (genre != null && !genre.isEmpty()) {
                    queryGet += " AND genre = '" + genre + "'";
                }

                ResultSet theResult = bookGet.executeQuery(queryGet);

                while (theResult.next()) {
                    String title = theResult.getString("title");
                    System.out.println("Found book: " + title);
                }
            }
        } catch (ClassNotFoundException e) {
            System.out.println("SQL Server JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
            e.printStackTrace();
        }
        
        
    }
    
    
    
    
    public static void startHttpServer(String url) {
        String server = "LAPTOP-EBU3JLQG";  
        String databaseName = "MyLibraryDatabase"; 
        try (ServerSocket serverSocket = new ServerSocket(8080)) {
            System.out.println("HTTP server running on port 8080...");
            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                     BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()))) {

                    // Read the HTTP request
                    String line;
                    StringBuilder requestBuilder = new StringBuilder();
                    while ((line = in.readLine()) != null && !line.isEmpty()) {
                        requestBuilder.append(line).append("\n");
                    }

                    // Parse HTTP request body (if any)
                    String requestBody = "";
                    while (in.ready()) {
                        requestBody += (char) in.read();
                    }
                    System.out.println("Received Request: " + requestBody);

                    // Extract the requested file or action
                    String[] requestLines = requestBuilder.toString().split("\n");
                    String requestMethod = requestLines[0].split(" ")[0]; // GET or POST
                    String requestedFile = requestLines[0].split(" ")[1]; // Requested file (e.g., /BookBrowse.html)

                    // Handle login POST request
                    if (requestMethod.equals("POST") && requestedFile.equals("/login")) {
                        String[] data = requestBody.split("&");
                        String username = data[0].split("=")[1];
                        String password = data[1].split("=")[1];

                        // Authenticate user
                        int result = login(username, password, url);
                        String SQLUrl = "jdbc:sqlserver://" + server + ":1433;databaseName=" + databaseName + ";integratedSecurity=true;encrypt=false;";
                        
                        login(username, password, SQLUrl);
                        
                        

                        // Prepare response JSON
                        String responseJson = "{\"success\": " + (result > 0) + ", \"user_type\": " + result + "}";

                        // Send response
                        out.write("HTTP/1.1 200 OK\r\n");
                        out.write("Content-Type: application/json\r\n");
                        out.write("Content-Length: " + responseJson.length() + "\r\n");
                        out.write("\r\n");
                        out.write(responseJson);
                        out.flush();

                        // After login, redirect to BookBrowsePage
                        if (result > 0) {
                            out.write("HTTP/1.1 302 Found\r\n");
                            out.write("Location: /BookBrowsePage/BookBrowse.html\r\n");
                            out.write("\r\n");
                            out.flush();
                        }

                    } else if (requestedFile.equals("/BookBrowsePage/BookBrowse.html")) {
                        // Serve the BookBrowse.html page
                        serveFile("C:\\Users\\Holme\\Documents\\Rosewood_Library_Folder\\Javascript_Website_Components\\RosewoodHTMLOrg\\BookBrowsePage\\BookBrowse.html", out);

                    } else {
                        // Serve other static files (CSS, JS, etc.)
                        serveFile("C:\\Users\\Holme\\Documents\\Rosewood_Library_Folder\\Javascript_Website_Components\\RosewoodHTMLOrg" + requestedFile, out);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("HTTP Server Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    
    
    
    public static void serveFile(String filePath, BufferedWriter out) throws IOException {
        File file = new File(filePath);
        if (file.exists()) {
            try (BufferedReader fileReader = new BufferedReader(new FileReader(file))) {
                String line;
                out.write("HTTP/1.1 200 OK\r\n");
                out.write("Content-Type: text/html\r\n");
                out.write("Content-Length: " + file.length() + "\r\n");
                out.write("\r\n");
                while ((line = fileReader.readLine()) != null) {
                    out.write(line + "\n");
                }
                out.flush();
            } catch (IOException e) {
                System.out.println("Error serving file: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            out.write("HTTP/1.1 404 Not Found\r\n");
            out.write("Content-Type: text/plain\r\n");
            out.write("\r\n");
            out.write("File not found.");
            out.flush();
        }
    }

    // User login interface - checks credentials in the database
    public static int login(String username, String password, String url) {
        String query = "SELECT is_admin FROM user_login WHERE user_id = ? AND password = ?";
        int result = 0;  // Default result (0 means user not found or error)

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            // Set the username and password in the prepared statement
            stmt.setString(1, username);
            stmt.setString(2, password);

            // Execute the query and retrieve the result
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // If a user is found, check if they are an admin
                    boolean isAdmin = rs.getBoolean("is_admin");
                    result = isAdmin ? 2 : 1;  // Return 2 for admin, 1 for regular user
                }
            }
        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
            e.printStackTrace();
        }

        return result;  // Return 0 if login failed, 1 for regular user, 2 for admin
    }
    
    
    
    
    
}
