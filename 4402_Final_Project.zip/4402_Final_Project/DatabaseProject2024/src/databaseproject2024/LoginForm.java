package databaseproject2024;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class LoginForm extends JFrame {
    private JTextField usernameField, nameField;
    private JPasswordField passwordField;
    private JCheckBox rememberMeCheckBox;
    private JButton loginButton, cancelButton, signUpButton, signUpSubmitButton;
    private JLabel errorMessageLabel;

    // Database connection details
    private final String server = "LAPTOP-EBU3JLQG";
    private final String databaseName = "MyLibraryDatabase";
    private final String connectionUrl = "jdbc:sqlserver://" + server + ":1433;databaseName=" + databaseName + ";integratedSecurity=true;encrypt=false;";

    public LoginForm() {
        // Set up frame
        setTitle("Rosewood Library - Login");
        setSize(800, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Set background image
        ImageIcon backgroundImage = new ImageIcon("public_library_image.jpg");
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setLayout(new BorderLayout());
        setContentPane(backgroundLabel);

        // Banner (logo at the top)
        JPanel bannerPanel = new JPanel();
        bannerPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        bannerPanel.setOpaque(false); // Make the banner transparent
        JLabel logoLabel = new JLabel(new ImageIcon("LogoWhite.png"));
        bannerPanel.add(logoLabel);
        add(bannerPanel, BorderLayout.NORTH);

        // Content panel with login form
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setOpaque(false); // Make the form background transparent

        // Username field
        JLabel usernameLabel = new JLabel("Username");
        usernameField = new JTextField(20);
        formPanel.add(usernameLabel);
        formPanel.add(usernameField);

        // Password field
        JLabel passwordLabel = new JLabel("Password");
        passwordField = new JPasswordField(20);
        formPanel.add(passwordLabel);
        formPanel.add(passwordField);

        // Remember me checkbox
        rememberMeCheckBox = new JCheckBox("Remember me");
        formPanel.add(rememberMeCheckBox);

        // Error message (hidden by default)
        errorMessageLabel = new JLabel("Invalid username or password. Please try again.");
        errorMessageLabel.setForeground(Color.RED);
        errorMessageLabel.setVisible(false);
        formPanel.add(errorMessageLabel);

        // Add form panel to center
        add(formPanel, BorderLayout.CENTER);

        // Footer (buttons for login, cancel, and sign-up)
        JPanel footerPanel = new JPanel();
        footerPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        footerPanel.setOpaque(false);

        // Login button
        loginButton = new JButton("Login");
        loginButton.setBackground(new Color(119, 221, 119)); // Greenish color
        loginButton.setForeground(Color.WHITE);
        loginButton.addActionListener(e -> handleLogin());
        footerPanel.add(loginButton);

        // Cancel button
        cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(128, 0, 32)); // Dark red color
        cancelButton.setForeground(Color.WHITE);
        cancelButton.addActionListener(e -> resetForm());
        footerPanel.add(cancelButton);

        // Sign-up button
        signUpButton = new JButton("Sign Up");
        signUpButton.setBackground(new Color(70, 130, 180)); // Steel blue color
        signUpButton.setForeground(Color.WHITE);
        signUpButton.addActionListener(e -> showSignUpForm());
        footerPanel.add(signUpButton);

        // Add footer panel at the bottom
        add(footerPanel, BorderLayout.SOUTH);
    }

    private void handleLogin() {
        String username = usernameField.getText();
        char[] password = passwordField.getPassword();

        int userType = validateCredentials(username, new String(password));

        if (userType > 0) { // Successful login
            JOptionPane.showMessageDialog(this, "Login successful!");

            if (userType == 2) {
                // Redirect to AdminPage for admin users
                new AdminPage(username).setVisible(true);
            } else {
                // Redirect to BookBrowsePage for regular users
                new LibraryBrowsePage(username).setVisible(true);
            }

            this.dispose(); // Close the login window
        } else {
            errorMessageLabel.setVisible(true); // Show error message if login fails
        }
    }

    private int validateCredentials(String username, String password) {
        String query = "SELECT is_admin FROM user_logins WHERE user_id = ? AND password = ?";
        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Check if the user is an admin
                boolean isAdmin = rs.getBoolean("is_admin");
                return isAdmin ? 2 : 1; // Return 2 for admin, 1 for regular user
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
        return 0; // Return 0 if login fails
    }

    private void resetForm() {
        usernameField.setText("");
        passwordField.setText("");
        rememberMeCheckBox.setSelected(false);
        errorMessageLabel.setVisible(false);
    }

    private void showSignUpForm() {
        JDialog signUpDialog = new JDialog(this, "Sign Up", true);
        signUpDialog.setSize(400, 300);
        signUpDialog.setLocationRelativeTo(this);

        JPanel signUpPanel = new JPanel();
        signUpPanel.setLayout(new GridLayout(4, 2, 10, 10));

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();
        JLabel usernameLabel = new JLabel("Username:");
        JTextField signUpUsernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField signUpPasswordField = new JPasswordField();

        signUpSubmitButton = new JButton("Submit");
        signUpSubmitButton.addActionListener(e -> {
            String name = nameField.getText();
            String username = signUpUsernameField.getText();
            String password = new String(signUpPasswordField.getPassword());
            handleSignUp(name, username, password);
            signUpDialog.dispose();
        });

        signUpPanel.add(nameLabel);
        signUpPanel.add(nameField);
        signUpPanel.add(usernameLabel);
        signUpPanel.add(signUpUsernameField);
        signUpPanel.add(passwordLabel);
        signUpPanel.add(signUpPasswordField);
        signUpPanel.add(new JLabel());
        signUpPanel.add(signUpSubmitButton);

        signUpDialog.add(signUpPanel);
        signUpDialog.setVisible(true);
    }

    private void handleSignUp(String name, String username, String password) {
        String query = "INSERT INTO user_logins (user_id, password, is_admin, name, charges) VALUES (?, ?, 0, ?, 0.00)";
        try (Connection conn = DriverManager.getConnection(connectionUrl);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, name);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Sign-up successful! You can now log in.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Sign-up failed: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginForm().setVisible(true);
        });
    }
}
