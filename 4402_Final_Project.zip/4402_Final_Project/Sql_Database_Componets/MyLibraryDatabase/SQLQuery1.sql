﻿INSERT into user_logins(user_id, password, is_admin, name)
VALUES('bitch', 'bitch', 0, 'bitch');